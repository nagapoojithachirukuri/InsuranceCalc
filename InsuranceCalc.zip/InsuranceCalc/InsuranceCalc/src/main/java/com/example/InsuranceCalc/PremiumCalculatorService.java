package com.example.InsuranceCalc;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PremiumCalculatorService {

    private final RateCard rateCard;

    @Autowired
    public PremiumCalculatorService(RateCard rateCard) {
        this.rateCard = rateCard;
    }

    public double calculatePremium(Family family) {
    	if (family == null || family.getMembers() == null) {
            throw new IllegalArgumentException("Family and family members cannot be null");
        }
        double totalPremium = family.getMembers().stream()
                .mapToDouble(this::calculateIndividualPremium)
                .sum();
        if (family.getMembers().stream().anyMatch(Person::isMilitary)) {
            totalPremium *= 0.85; // 15% discount
        }
        return totalPremium;
    }

    private double calculateIndividualPremium(Person person) {
    	if (person == null) {
            throw new IllegalArgumentException("Person cannot be null");
        }
        double rate = rateCard.getRateForAge(person.getAge());
        if (person.getAge() > 55 && !person.hasPreExistingConditions()) {
            rate *= 0.90; // 10% discount
        }
        return rate;
    }
}
