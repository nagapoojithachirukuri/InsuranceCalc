package com.example.InsuranceCalc;


import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;


@NoArgsConstructor
@AllArgsConstructor
public class Family {
    private List<Person> members;
    
    @JsonCreator
    public Family(@JsonProperty("members") List<Person> members) {
        this.members = members;
    }
    
    public List<Person> getMembers() {
        return members;
    }

    public void setMembers(List<Person> members) {
        this.members = members;
    }
}

