package com.example.InsuranceCalc;

import java.util.NavigableMap;
import java.util.TreeMap;

import org.springframework.stereotype.Component;

@Component
public class RateCard {
    private final NavigableMap<Integer, Double> rates = new TreeMap<>();

    public RateCard() {
    	rates.put(14, 345.11);
        rates.put(15, 375.78);
        rates.put(16, 387.51);
        rates.put(17, 399.24);
        rates.put(18, 411.87);
        rates.put(19, 424.50);
        rates.put(20, 437.59);
        rates.put(21, 451.12);
        rates.put(22, 451.12);
        rates.put(23, 451.12);
        rates.put(24, 451.12);
        rates.put(25, 452.92);
        rates.put(26, 461.95);
        rates.put(27, 472.77);
        rates.put(28, 490.37);
        rates.put(29, 504.80);
        rates.put(30, 512.02);
        rates.put(31, 522.85);
        rates.put(32, 533.67);
        rates.put(33, 540.44);
        rates.put(34, 547.66);
        rates.put(35, 551.27);
        rates.put(36, 554.88);
        rates.put(37, 558.49);
        rates.put(38, 562.10);
        rates.put(39, 569.31);
        rates.put(40, 576.53);
        rates.put(41, 587.36);
        rates.put(42, 597.73);
        rates.put(43, 612.17);
        rates.put(44, 630.21);
        rates.put(45, 651.42);
        rates.put(46, 676.68);
        rates.put(47, 705.10);
        rates.put(48, 737.58);
        rates.put(49, 769.61);
        rates.put(50, 805.70);
        rates.put(51, 841.34);
        rates.put(52, 880.59);
        rates.put(53, 920.28);
        rates.put(54, 963.14);
        rates.put(55, 1006.00);
        rates.put(56, 1052.46);
        rates.put(57, 1099.38);
        rates.put(58, 1149.45);
        rates.put(59, 1174.27);
        rates.put(60, 1224.34);
        rates.put(61, 1267.65);
        rates.put(62, 1296.07);
        rates.put(63, 1331.71);
        rates.put(64, 1353.36);
    }

    public double getRateForAge(int age) {
        return rates.ceilingEntry(age).getValue();
    }
}
