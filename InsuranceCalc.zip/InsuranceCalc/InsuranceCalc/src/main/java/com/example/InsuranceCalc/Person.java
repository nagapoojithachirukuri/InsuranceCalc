package com.example.InsuranceCalc;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class Person {
    private int age;
    private boolean isMilitary;
    private boolean hasPreExistingConditions;


	// Getters and Setters
    public int getAge() {
        return age;
    }

    public boolean isMilitary() {
        return isMilitary;
    }

    public boolean hasPreExistingConditions() {
        return hasPreExistingConditions;
    }

    // Additional setters
}

