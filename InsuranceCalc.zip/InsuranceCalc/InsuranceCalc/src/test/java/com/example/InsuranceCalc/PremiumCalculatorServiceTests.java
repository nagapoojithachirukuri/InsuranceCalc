package com.example.InsuranceCalc;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.Arrays;
import java.util.Collections;

class PremiumCalculatorServiceTests {

    private final RateCard rateCard = new RateCard();
    private final PremiumCalculatorService service = new PremiumCalculatorService(rateCard);

    @Test
    void calculatePremium_minimumAge() {
        Family family = new Family(Collections.singletonList(new Person(14, false, false)));
        double expected = rateCard.getRateForAge(14);
        assertEquals(expected, service.calculatePremium(family));
    }

    @Test
    void calculatePremium_maximumAge() {
        Family family = new Family(Collections.singletonList(new Person(64, false, false)));
        double rate = rateCard.getRateForAge(64);
        double expected = rate * 0.90; // Apply 10% senior discount
        assertEquals(expected, service.calculatePremium(family), 0.01);
    }

    @Test
    void calculatePremium_aboveMaximumAge() {
        Family family = new Family(Collections.singletonList(new Person(65, false, false)));
        assertThrows(NullPointerException.class, () -> service.calculatePremium(family));
    }

    @Test
    void calculatePremium_noDiscounts() {
        Family family = new Family(Collections.singletonList(new Person(30, false, false)));
        double expected = rateCard.getRateForAge(30);
        assertEquals(expected, service.calculatePremium(family));
    }

    @Test
    void calculatePremium_militaryDiscount() {
        Family family = new Family(Collections.singletonList(new Person(30, true, false)));
        double expected = rateCard.getRateForAge(30) * 0.85; // 15% military discount
        assertEquals(expected, service.calculatePremium(family));
    }

    @Test
    void calculatePremium_seniorDiscount() {
        Family family = new Family(Collections.singletonList(new Person(56, false, false)));
        double expected = rateCard.getRateForAge(56) * 0.90; // 10% senior discount
        assertEquals(expected, service.calculatePremium(family));
    }

    @Test
    void calculatePremium_preExistingConditions() {
        Family family = new Family(Collections.singletonList(new Person(56, false, true)));
        double expected = rateCard.getRateForAge(56); // No senior discount due to pre-existing conditions
        assertEquals(expected, service.calculatePremium(family));
    }

    @Test
    void calculatePremium_militaryAndSeniorDiscounts() {
        Family family = new Family(Collections.singletonList(new Person(56, true, false)));
        double expected = rateCard.getRateForAge(56) * 0.90 * 0.85; // Senior discount then military discount
        assertEquals(expected, service.calculatePremium(family));
    }

    @Test
    void calculatePremium_familyWithMixedDiscounts() {
        Family family = new Family(Arrays.asList(
            new Person(56, true, false),   // Senior and military discounts
            new Person(30, false, false),  // No discounts
            new Person(45, false, false),  // No discounts
            new Person(60, false, false),  // Senior discount
            new Person(25, true, false)    // Military discount
        ));

        double individualPremium1 = rateCard.getRateForAge(56) * 0.90; // Senior discount
        double individualPremium2 = rateCard.getRateForAge(30);        // No discount
        double individualPremium3 = rateCard.getRateForAge(45);        // No discount
        double individualPremium4 = rateCard.getRateForAge(60) * 0.90; // Senior discount
        double individualPremium5 = rateCard.getRateForAge(25);        // No discount (military discount applies at family level)

        double totalPremium = individualPremium1 + individualPremium2 + individualPremium3 + individualPremium4 + individualPremium5;
        totalPremium *= 0.85; // Family has at least one military member

        assertEquals(totalPremium, service.calculatePremium(family));
    }

    @Test
    void calculatePremium_emptyFamily() {
        Family family = new Family(Collections.emptyList());
        double expected = 0.0;
        assertEquals(expected, service.calculatePremium(family));
    }


    @Test
    void calculatePremium_familyWithPreExistingConditions() {
        Family family = new Family(Arrays.asList(
            new Person(56, false, true), // Pre-existing conditions, no senior discount
            new Person(60, false, false) // Senior discount applies
        ));

        double individualPremium1 = rateCard.getRateForAge(56);         // No discount
        double individualPremium2 = rateCard.getRateForAge(60) * 0.90;  // Senior discount

        double totalPremium = individualPremium1 + individualPremium2;

        assertEquals(totalPremium, service.calculatePremium(family));
    }

    @Test
    void calculatePremium_familyAllMilitary() {
        Family family = new Family(Arrays.asList(
            new Person(30, true, false),
            new Person(25, true, false),
            new Person(18, true, false)
        ));

        double totalPremium = rateCard.getRateForAge(30)
                            + rateCard.getRateForAge(25)
                            + rateCard.getRateForAge(18);
        totalPremium *= 0.85; // Family military discount

        assertEquals(totalPremium, service.calculatePremium(family));
    }

    @Test
    void calculatePremium_familyNoDiscounts() {
        Family family = new Family(Arrays.asList(
            new Person(30, false, true),  // Not military, has pre-existing conditions
            new Person(45, false, false), // Not military, no pre-existing conditions
            new Person(50, false, true)   // Not military, has pre-existing conditions
        ));

        double totalPremium = rateCard.getRateForAge(30)
                            + rateCard.getRateForAge(45)
                            + rateCard.getRateForAge(50);

        // Include a delta to account for floating-point precision
        assertEquals(totalPremium, service.calculatePremium(family), 0.01);
    }


}
