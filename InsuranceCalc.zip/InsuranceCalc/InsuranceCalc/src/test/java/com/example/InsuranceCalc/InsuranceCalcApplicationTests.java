package com.example.InsuranceCalc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InsuranceCalcApplicationTests {

	@Test
	void contextLoads() {
	}

}
