

1. Build the Project: mvn clean package
2. Run the Application: java -jar target/InsuranceCalc-1.0.0.jar
3. Access Swagger UI: Open your browser and navigate to http://localhost:8080/swagger-ui/index.html.
4. Run JUnit Tests: mvn test